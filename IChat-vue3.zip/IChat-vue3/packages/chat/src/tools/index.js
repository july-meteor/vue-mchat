
import ToolsIndex from './src/index.vue'

ToolsIndex.install = function (Vue) {
    Vue.component(ToolsIndex.name, ToolsIndex)
}

export default ToolsIndex