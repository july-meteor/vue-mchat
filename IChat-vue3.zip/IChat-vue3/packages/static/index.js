export const default_avatar = require('./images/default_avatar.png');

export const default_unnoticed = require("./images/unnotic.png");

export const tipSound = require('./media/tip.wav');

