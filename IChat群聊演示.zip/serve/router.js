const express = require('express');
const router = express.Router();
const login = require("./controller/login")
const config =  require("./controller/initConfig")
// const update =  require("./controller/updateFile")



config(router)
login(router)
// update(router)


router.use((err, req, resp, next) => {
    resp.status(err.statusCode || 500).send(err);
})


// 文件上传
const multer = require('multer');
const upload = multer({
    dest: __dirname + '/uploads'
})

router.post('/upload', upload.single('file'), (req, resp) => {
    // const filePath = 'http://www.julymeteor.com/im/uploads/' + req.file.filename;
    const filePath = 'http://localhost:8083/uploads/' + req.file.filename;
    resp.send(filePath);
})

// router.get('/favicon.ico', function (req, resp) {
//     fs.readFile('./uploads/img02.jpg', function (err, data) {
//         resp.setHeader('Content-Type', 'image/jpeg')
//         resp.end(data);
//     })
// })




module.exports = router;