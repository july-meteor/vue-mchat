const mongoose = require('mongoose');


const schema = new mongoose.Schema({
    // 消息id
    id: {type: Number, default: 1, unique: true},
    from: {type: Object, required: true},
    to: {type: Object, required: true},
    message: {type: String},
    status: {type: String},
    timestamp: {type: Number},
    type: {type: String},
})

const model = mongoose.model('System', schema);
module.exports = model