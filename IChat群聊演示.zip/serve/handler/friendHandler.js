const {addFriend, pushFriends} = require("../biz/IFriend");
const {notifyUserByUid} = require("../biz/INotify");
const User = require("../models/User")
const System = require("../models/System");
const {createSystemMessage, editSystemMessageStatus, getSystemMessage, pushMessages} = require("../biz/ISystem");

/*
*   好友群组相关
 */
module.exports = (channel, event) => {
    let {onlineUserCount, serve, onlineUsers, socket} = channel;
    event.on("pull_friend", async () => {
        if (!socket._id) {
            return
        }
        const user = await User.findById(socket._id).populate("friends");
        pushFriends(user.friends, socket);
    });


    // 申请好友
    event.on("apply_friend", async (data) => {
        data.type = 'applyFriend';
        const sys_msg = await createSystemMessage(data);
        getSystemMessage(sys_msg, channel);
    });

    // 同意好友申请
    event.on("accept_friend", async (data) => {
        let {id, from, to} = data
        await addFriend(from.id, to.id);
        const model = await  editSystemMessageStatus(id, 'accept')
        // 更新系统请求
        let form = {
            from: model.to,
            to: model.from,
            type: 'acceptFriend',
            message: '已经同意你的好友申请',
            timestamp: new Date(),
        }
        const sys_msg = await createSystemMessage(form);
        //给2个人发通知
        pushMessages(from.id, socket);
        getSystemMessage(sys_msg, channel);
        // 通知2个人好友变更
        notifyUserByUid(from.id, "change_status_friend", null, channel)
        notifyUserByUid(to.id, "change_status_friend", null, channel)
    });

    // 拒接好友申请
    event.on("reject_friend", async (data) => {
        let {id, from, to} = data
        const model = await  editSystemMessageStatus(id, 'reject')
        // 更新系统请求
        let form = {
            from: model.to,
            to: model.from,
            type: 'rejectFriend',
            message: '拒接了你的好友申请',
            timestamp: new Date(),
        }
        const sys_msg = await createSystemMessage(form);
        //给2个人发通知
        pushMessages(from.id, socket);
        getSystemMessage(sys_msg, channel);
    });

};





