
function put(io, data) {
    // 告诉用户消息发送成功
    io.emit('successful', data);
}
const {strEquals, valueEquals} = require('../utils/util')

// 当做一个类来写
module.exports = (handler) => {
    //客户端连接数量
    let onlineUserCount = 0;
    //统计客户端登录用户
    let onlineUsers = {};


    handler.on("open", (serve, socket) => {
        function findSocketById(id) {
            for (const item in onlineUsers) {
                 let temp = onlineUsers[item]
                // Mongodb 唯一id 有点坑
                if (strEquals(temp._id, id)) {
                    return serve.sockets.sockets[temp.sid];
                }
            }
        }

        function findSocketByUId(UId) {
            // 判断下是否存在
            if (onlineUsers.hasOwnProperty(UId)) {
                let temp = onlineUsers[UId];
                return serve.sockets.sockets[temp.sid];
            }
        }

        // 前置拦截
        let channel = {
            serve,
            onlineUserCount,
            onlineUsers,
            socket,
            findSocketById,
            findSocketByUId,

        }
        // 事件分发
        const EventEmitter = require('events');
        const event = new EventEmitter();
        // 基础事件处理
        const base = require("./baseHandler")
        const group = require("./groupHandler")
        const friend = require("./friendHandler")
        const message = require("./messageHandler")


        base(channel, event);
        group(channel, event);
        friend(channel, event);
        message(channel, event);

        // const room =  require("./roomHandler")
        // room(channel,event);

        // 注册事件
        let events = event._events;
        for (let key in events) {
            socket.on(key, events[key]);
        }
    })
}





