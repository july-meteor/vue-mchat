const User = require("../models/User")


async function getUserById(userId) {
    return await  User.findById(userId);
}

async function getUserByUId(userId) {
    return await  User.findOne({id: userId});
}

async function getFriendByUId(userId) {
    const user = await  User.findOne({id: userId}).populate("friend");
    return user.friends;
}

async function updateFriendById(_id, friends) {
    return await User.findByIdAndUpdate(_id, {
        $set: {
            friends,
        }
    }, {new: true});
}


async function updateFriendByUId(userId, friends) {

    return await User.findOneAndUpdate({id: userId}, {
        $set: {
            friends,

        }
    }, {new: true});
}

function findOnlineBy_Id() {

}


module.exports = {
    getUserByUId,
    updateFriendById,
    updateFriendByUId,

}