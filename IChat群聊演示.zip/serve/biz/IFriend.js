const {getUserByUId, updateFriendById, getFriendByUId ,updateFriendByUId} = require('./IUser');



/**
 *  同意好友申请
 * @returns {Promise<void>}
 */
async function addFriend(uid, fid) {
    const mine = await getUserByUId(uid);
    const friend = await getUserByUId(fid);

    const m_temp = mine.friends;
    const f_temp = friend.friends;
    m_temp.push(friend._id);
    f_temp.push(mine._id);
    await updateFriendByUId(uid, m_temp);

    await updateFriendByUId(fid, f_temp);

}




/**
 *  推送好友
 * @param friends
 * @param socket
 * @returns {Promise<void>}
 */
async function pushFriends(friends = [], socket) {
    let userList = [];
    for (let item of friends) {
        let temp = {
            id: item.id,
            _id: item._id,
            name: item.name,
            online: item.online,
            avatar: item.avatar,
            sign: item.sign,
            role: undefined
        };
        userList.push(temp)
    }
    let friendList = [
        {
            id: 0,
            index: 0,
            name: '我的好友',
            userList,
        }
    ];
    socket.emit("push_friends", friendList)
}


module.exports = {
    addFriend,
    pushFriends,
}
