const System = require("../models/System");
const User = require("../models/User");


/**
 *  增加系统消息
 * @returns {Promise<void>}
 */
async function createSystemMessage(form) {
    const last = await  System.findOne({}).sort({id: -1});
    form.timestamp = new Date();
    if (last) {
        form.id = last.id + 1;
    }
    const system = await System.create(form);
    const user = await User.findOne({id: form.to.id})

    const systemList = user.system;
    systemList.push(system._id);
    await User.findByIdAndUpdate(user._id, {
        $set: {
            system: systemList
        }
    }, {new: true});
    return system;
}

async function editSystemMessageStatus(messageId, status) {
    const message = await System.findOneAndUpdate({id: messageId}, {
        $set: {
            status,
            timestamp: new Date(),
        }
    }, {new: true});

    return message;
}

/**
 *  初始化的时候获取
 * @returns {Promise<void>}
 */
async function pushMessages(id, socket) {
    const user = await  User.findOne({id: id}).populate('system');
    const  systems =user.system;
    socket.emit("push_system_message", systems);
}


/**
 *  推送一条
 * @returns {Promise<void>}
 */
async function getSystemMessage(model, channel) {
    let {findSocketByUId} = channel;

    const toSocket = findSocketByUId(model.to.id);
    if (toSocket) {
        toSocket.emit("getSystemMessage", model);
    }
}


module.exports = {
    createSystemMessage,
    editSystemMessageStatus,
    pushMessages,
    getSystemMessage,
}
