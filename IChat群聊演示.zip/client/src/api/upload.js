import request from '../utils/request'


const qs = require('querystring');// 使用querystring 或者qs 库
/**
 *  登录平台
 * @param form
 */
export  function  uploadFile(form) {
    const formdata = new FormData();
    formdata.append("file", form.file);
    return request.post("/im/upload", formdata);

    // return request({
    //     url:"/im/upload",
    //     method:'post',
    //     data:qs.stringify(form),
    //
    // })
}

