<template>
    <m-dialog
            title="MChat"
            :shrink="true"
            :showClose="false"
            :visible.sync="show"
    >
        <div v-if="!register">
            <div class="login-form">
                <div class="login-form-item">
                    <div class="input">
                        <input type="text" @keydown.enter="handlerLogin" slot="reference" v-model="loginForm.account"
                               placeholder="账号">
                    </div>
                    <div class="error" :style="{ visibility: !!visibleAccount ? 'visible' : 'hidden' }">请你输入账号在登录</div>
                </div>
                <div class="login-form-item">
                    <div class="input">
                        <input type="password" @keydown.enter="handlerLogin" slot="reference"
                               v-model="loginForm.password" placeholder="密码">
                    </div>
                    <div class="error" :style="{ visibility :!!visiblePassword ? 'visible' : 'hidden' }">请你输入密码在登录</div>
                </div>
            </div>
            <div class="funGroup">
                <input type="checkbox" class="fun" value="自动登录">
                <span>
                        自动登录
                    </span>

            </div>
            <div class="funGroup">
                <input type="checkbox" class="fun" value="记住密码"> <span>
                       记住密码
                    </span>
            </div>
            <div class="funGroup">
                     <span>
                        找回密码
                    </span>
            </div>
            <div style="padding: 10px">
                <span class="register" @click="register=true">注册账号</span>
                <button class="m-button m-button-primary" @click="handlerLogin" style="width: 235px">
                    <span>登 录</span>
                </button>
            </div>
        </div>
        <div v-else>
            <div style="width: 439px;padding: 20px;">
                <div class="input">
                    <input type="text" v-model="registerForm.name" placeholder="昵称">
                </div>
                <div class="input">
                    <input type="text" v-model="registerForm.account" placeholder="账号">
                </div>
                <div class="input">
                    <input type="password" v-model="registerForm.password" placeholder="密码">
                </div>
            </div>
            <div style="padding: 10px">
                <span class="register" @click="register=false">返回</span>
                <button class="m-button m-button-primary" @click="handlerRegister" style="width: 235px">
                    <span>注  册</span>
                </button>
            </div>
        </div>
    </m-dialog>


</template>

<script>
    import {register, login} from '../api/login'

    const defaultLoginForm = {
        account: undefined,
        password: undefined,
    }


    const defaultRegisterForm = {
        account: undefined,
        name: undefined,
        password: undefined,
    }

    export default {
        name: "app",
        data() {
            return {
                show: true,
                register: false,
                registerForm: Object.assign({}, defaultRegisterForm),
                loginForm: Object.assign({}, defaultLoginForm),
                visiblePassword: false,
                visibleAccount: false,
            }
        },
        methods: {
            // 账号注册
            handlerRegister() {
                register(this.registerForm).then(res => {
                    const {flag, msg, data} = res;
                    if (!flag) {
                        this.$INotify({
                            title: '警告',
                            message: msg,
                            type: 'warning'
                        });
                        return
                    }
                    this.$INotify({
                        title: '成功',
                        message: '注册成功！',
                        type: 'success'
                    });
                    this.registerForm = Object.assign({}, defaultRegisterForm);
                    this.register = false;
                })
            },
            handlerLogin() {

                if (!this.loginForm.account) {
                    this.visibleAccount = true;
                    return
                } else {
                    this.visibleAccount = false;
                }

                if (!this.loginForm.password) {
                    this.visiblePassword = true;
                    return
                } else {
                    this.visiblePassword = false;
                }

                login(this.loginForm).then(res => {
                    const {flag, msg, data} = res;
                    if (!flag) {
                        this.$INotify({
                            title: '警告',
                            message: msg,
                            type: 'warning'
                        });
                        return
                    }
                    const {token} = data;
                    this.$INotify({
                        title: '成功',
                        message: '登录成功！',
                        type: 'success'
                    });
                    sessionStorage.setItem("token", token);
                    this.$emit("login");
                })
            }
        },
        mounted() {

        }
    }
</script>

<style scoped>
    .fun {
        margin-right: 5px;
    }

    .register {
        font-size: 14px;
        position: absolute;
        left: 15px;
        color: #A6A6A6;
        bottom: 15px;
    }

    .funGroup {
        width: 100px;
        display: inline-block;
        color: #A6A6A6;
    }

    .funGroup:hover, .register:hover {
        color: #409eff;
    }

    .input {
        height: 45px;
        width: 100%;
        border-radius: 25px;
        display: flex;
        justify-content: center;
        /*align-items: center;*/
        transition: .3s;

    }

    .login-form {
        padding: 10px 40px;

    }

    .login-form-item {
        line-height: 40px;
        position: relative;
        font-size: 14px;
        margin-bottom: 22px;
    }

    .error {
        color: #f56c6c;
        font-size: 12px;
        line-height: 1;
        padding-top: 4px;
        position: absolute;
        top: 100%;
        left: 0;

    }

    input[type="text"], input[type="password"] {
        /*background-color: rgb(250, 255, 189);*/
        background-color: #fff;
        border: 1px solid rgba(0, 0, 0, .15);
        padding-left: 1em;
        width: 23em;
        height: 2.8em;
        margin-bottom: 1.2em;
    }


</style>