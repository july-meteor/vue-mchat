<template>

    <IChat
            ref="IChat"
            :mine="mine"
            @bindEvent="handleEvent"
    >
    </IChat>

</template>

<script>
    import {uploadFile} from '../api/upload'

    export default {
        name: "Client",
        props: {
            user: {
                type: Object,
                default: () => {
                },
            },
        },
        data() {
            return {
                mine: {},
            };
        },
        created() {
            this.initChat();
            this.socket.on("push_groups", (groups) => {
                console.log("拉取群组", groups)
                this.$refs.IChat.setGroups(groups);
            });
            this.socket.on("push_friends", (friends) => {
                console.log("拉取好友", friends)
                this.$refs.IChat.setFriends(friends);

            });
            this.socket.on("push_system_message", (message) => {
                console.log("拉取系统消息", message)
                this.$refs.IChat.setSystemMessage(message);
            });

            this.socket.on("getSystemMessage", (message) => {
                console.log("获取系统消息", message)
                this.$refs.IChat.newSystemMessage(message);
            });

            // 接受消息
            this.socket.on("receive", (data) => {
                console.log("获得消息", data)
                this.$refs.IChat.getMessage(data);
            });

            this.socket.on("change_status_group", () => {
                // 通知用户更新群组 需要加锁。
                this.socket.emit("pull_group")
            })
            this.socket.on("change_status_friend", () => {
                // 通知用户更新群组 需要加锁。
                console.log("change_status_friend")
                this.socket.emit("pull_friend")
            })
        },
        methods: {
            initChat() {
                this.mine = {
                    username: this.user.name,
                    id: this.user.id,
                    status: "online",
                    avatar: this.user.avatar,
                };
                let msg = {account: this.user.account};
                if (msg) {
                    this.socket.emit("online", msg);
                }
            },
            handleEvent(event, data) {
                switch (event) {
                    case "sendMessage":
                        this.sendMessage(data);
                        break;
                    case "applyFriend":
                        this.handleApplyFriend(data);
                        break;
                    case "acceptFriend":
                        this.handleAcceptFriend(data);
                        break;
                    case "uploadEvent":
                        this.handleUpload(data)
                        break
                    default :
                        console.log("事件", event)
                        break;
                }
            },
            handleApplyFriend(model) {
                this.socket.emit("apply_friend", model)
            },
            handleAcceptFriend(data) {
                this.socket.emit("accept_friend", data.data)
            },

            sendMessage(data) {
                let _this = this;
                // 神奇的回调。。
                this.socket.emit("message", data, function (params) {
                    params.mine = true;
                    _this.$refs.IChat.getMessage(params);
                });
            },
            handleUpload({data, callback}) {
                uploadFile(data).then(res => {
                    callback(res)
                })
            }
        },
        mounted() {

        },
    };
</script>
