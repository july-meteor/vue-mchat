import Vue from 'vue'
import App from './App.vue'
// import MChat from '../../../packages/index'
import  '../lib/MChat.css'
import MChat from '../lib/MChat.umd'

import io from "socket.io-client"

Vue.config.productionTip = false
const url = 'http://localhost:8083'
const socket = io(url);
Vue.use(MChat)
//插入
Vue.mixin({
    data() {
        return {
            socket
        }
    }
})
new Vue({
  render: h => h(App),
}).$mount('#app')
